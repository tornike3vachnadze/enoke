export const firebaseConfig = {
  apiKey: "AIzaSyDANzUtVXDaNMCK5rbfo1r6qTly30--82M",
  authDomain: "enok-mobile.firebaseapp.com",
  projectId: "enok-mobile",
  storageBucket: "enok-mobile.appspot.com",
  messagingSenderId: "109600107400",
  appId: "1:109600107400:web:69f9a6bb08e5ea5de5e83d",
  measurementId: "G-PLFQ4W7TDC",
};

export const BACKEND_URL = "https://api.enok.com";
// export const BACKEND_URL = "http://localhost:4000";
