import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Image,
  ScrollView,
  StyleSheet,
  Dimensions,
  Text,
  TouchableOpacity,
  PanResponder,
} from "react-native";
import Button from "../Button";
import { ItemTypes } from "../../types";
import StickerGroup from "../Board/group/StickerGroup";
import TextToolBar from "./TextToolBar";
import BoardToolBar from "./BoardToolBar";
import VideoToolBar from "./VideoToolBar";
import LineToolBar from "./LineToolBar";
import DrawingToolBar from "./DrawingToolBar";
import ListToolBar from "./ListToolBar";
import ColumnToolBar from "./ColumnToolBar";
import FileToolBar from "./FileToolBar";
import StickerToolBar from "./StickerToolBar";
import AudioToolBar from "./AudioToolBar";
import ImageToolBar from "./ImageToolBar";
import UrlToolBar from "./UrlToolBar";
import CameraToolBar from "./CameraToolBar";
import {
  Gesture,
  GestureDetector,
  PanGestureHandler,
  GestureHandlerRootView,
} from "react-native-gesture-handler";
import TextContent from "../Board/content/Text";
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated";

interface ToolbarProps {
  editMode: boolean;
  addMode: { type: ItemTypes; target: any } | null;
  setEditMode: (editMode: boolean) => void;
  setAddMode: (addMode: { type: ItemTypes; target: any } | null) => void;
  removeElementFromBoard: () => void;
  handleStickerChose: (data: any) => void;
  selectedItemId?: string;
  selectedItemType: ItemTypes | null;
  setSelectedItemType: (selectedItemType: ItemTypes | null) => void;
}

const { width, height } = Dimensions.get("window");

const MainToolSetsWithSharingMode: React.FC<ToolbarProps> = ({
  editMode,
  addMode,
  setEditMode,
  setAddMode,
  removeElementFromBoard,
  handleStickerChose,
  selectedItemId,
  selectedItemType,
  setSelectedItemType,
}) => {
  return (
    <>
      <View>
        <Button.Round title="React">
          <Image source={require("../../assets/icons/smile.png")} />
        </Button.Round>
      </View>
      <View>
        <Button.Round title="Share">
          <Image source={require("../../assets/icons/share.png")} />
        </Button.Round>
      </View>
      <View>
        <Button.Round title="0">
          <Image source={require("../../assets/icons/chat.png")} />
        </Button.Round>
      </View>

      <View>
        <Button.Round onPress={() => setEditMode(!editMode)}>
          <Image source={require("../../assets/icons/plus.png")} />
        </Button.Round>
      </View>
    </>
  );
};

const MainToolSetsWithEditMode: React.FC<ToolbarProps> = ({
  editMode,
  addMode,
  setEditMode,
  setAddMode,
  removeElementFromBoard,
  handleStickerChose,
  selectedItemId,
  selectedItemType,
  setSelectedItemType,
}) => {
  const [isStartDragText, setISStartDragText] = useState(false);
  const [contentSize, setContentSize] = useState(0);
  const [test, setTest] = useState(false);
  const [isDraggingText, setIsDraggingText] = useState(false);
  const Opacity = useSharedValue(0);
  const END_POSITION = 100;
  const onLeft = useSharedValue(true);
  const position = useSharedValue(0);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);

  const panGesture = Gesture.Pan()
    .onBegin((e) => {
      Opacity.value = withTiming(1, { duration: 2 });
      console.log("asdfasdfsd");
    })
    .onUpdate((e) => {
      runOnJS(setISStartDragText)(true);
      if (onLeft.value) {
        translateX.value = e.translationX;
        translateY.value = e.translationY;
      } else {
        translateX.value = END_POSITION + e.translationX;
        translateY.value = END_POSITION + e.translationY;
      }
    })
    .onEnd((e) => {
      // if (translateX.value > END_POSITION / 2) {
      //   translateX.value = withTiming(END_POSITION, { duration: 0 });
      //   translateY.value = withTiming(END_POSITION, { duration: 0 });
      //   onLeft.value = false;
      // } else {
      //   translateX.value = withTiming(0, { duration: 0 });
      //   translateY.value = withTiming(0, { duration: 0 });
      //   onLeft.value = true;
      // }
      console.log("wwwwww1", e);
    })
    .onFinalize((e) => {
      Opacity.value = withTiming(0, { duration: 2 });
      console.log("wwwwww2", e);
      runOnJS(setAddMode)({ type: "text", target: e });
      runOnJS(setISStartDragText)(false);
    });

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
    ],
  }));

  const animatedStyle1 = useAnimatedStyle(() => ({
    opacity: Opacity.value,
  }));

  return (
    <>
      <GestureHandlerRootView>
        <GestureDetector gesture={panGesture}>
          <>
            <Animated.View>
              <Button.Square
                title="Text"
                // onPress={() =>
                //   // addMode.type === "text" ? setAddMode(null) : setAddMode("text")
                // }
                active={addMode?.type === "text"}
              >
                <Image source={require("../../assets/icons/text.png")} />
              </Button.Square>
            </Animated.View>

            {isStartDragText ? (
              <Animated.View style={[animatedStyle, { position: "absolute" }]}>
                <Text
                  style={{ fontSize: 16, width: 500 }}
                  numberOfLines={1}
                  className={`font-bold font-satoshi-bold text-lg text-design-primary`}
                >
                  Hold me to Start typing...
                </Text>
              </Animated.View>
            ) : null}
          </>
        </GestureDetector>
      </GestureHandlerRootView>

      <View>
        <Button.Square
          title="Image"
          onPress={() =>
            addMode === "image" ? setAddMode(null) : setAddMode("image")
          }
          active={addMode === "image"}
        >
          <Image source={require("../../assets/icons/image.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="Video"
          onPress={() =>
            addMode === "video" ? setAddMode(null) : setAddMode("video")
          }
          active={addMode === "video"}
        >
          <Image source={require("../../assets/icons/image.png")} />
        </Button.Square>
      </View>

      <View>
        <Button.Square
          title="Camera"
          onPress={() =>
            addMode === "camera" ? setAddMode(null) : setAddMode("camera")
          }
          active={addMode === "camera"}
        >
          <Image source={require("../../assets/icons/camera.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="Voice"
          onPress={() =>
            addMode === "audio" ? setAddMode(null) : setAddMode("audio")
          }
          active={addMode === "audio"}
        >
          <Image source={require("../../assets/icons/voice.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="List"
          onPress={() =>
            addMode === "list" ? setAddMode(null) : setAddMode("list")
          }
          active={addMode === "list"}
        >
          <Image source={require("../../assets/icons/list.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="Column"
          onPress={() =>
            addMode === "column" ? setAddMode(null) : setAddMode("column")
          }
          active={addMode === "column"}
        >
          <Image source={require("../../assets/icons/column.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="Sticker"
          onPress={() =>
            addMode === "sticker" ? setAddMode(null) : setAddMode("sticker")
          }
          active={addMode === "sticker"}
        >
          <Image source={require("../../assets/icons/sticker.png")} />
        </Button.Square>
        {addMode === "sticker" && (
          <StickerGroup onStickerChose={handleStickerChose} />
        )}
      </View>
      <View>
        <Button.Square
          title="Link"
          onPress={() =>
            addMode === "url" ? setAddMode(null) : setAddMode("url")
          }
          active={addMode === "url"}
        >
          <Image source={require("../../assets/icons/camera.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="Draw"
          onPress={() =>
            addMode === "drawing" ? setAddMode(null) : setAddMode("drawing")
          }
          active={addMode === "drawing"}
        >
          <Image source={require("../../assets/icons/pencil.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="Line"
          onPress={() =>
            addMode === "line" ? setAddMode(null) : setAddMode("line")
          }
          active={addMode === "line"}
        >
          <Image source={require("../../assets/icons/line.png")} />
        </Button.Square>
      </View>
      <View>
        <Button.Square
          title="File"
          onPress={() =>
            addMode === "file" ? setAddMode(null) : setAddMode("file")
          }
          active={addMode === "file"}
        >
          <Image source={require("../../assets/icons/file-upload.png")} />
        </Button.Square>
      </View>
      {/* <View>
        <Button.Square
          title="Board"
          onPress={() =>
            addMode === "board" ? setAddMode(null) : setAddMode("board")
          }
          active={addMode === "board"}
        >
          <Image source={require("../../assets/icons/file-upload.png")} />
        </Button.Square>
      </View> */}
    </>
  );
};

const CustomToolbar: React.FC<ToolbarProps> = ({
  editMode,
  addMode,
  setEditMode,
  setAddMode,
  removeElementFromBoard,
  handleStickerChose,
  selectedItemId,
  selectedItemType,
  setSelectedItemType,
}) => {
  if (editMode) {
    switch (selectedItemType) {
      case "text":
        return <TextToolBar />;
      case "image":
        return <ImageToolBar />;
      case "audio":
        return <AudioToolBar />;
      case "camera":
        return <CameraToolBar />;
      case "video":
        return <VideoToolBar />;
      case "url":
        return <UrlToolBar />;
      case "line":
        return <LineToolBar />;
      case "sticker":
        return <StickerToolBar />;
      case "drawing":
        return <DrawingToolBar />;
      case "list":
        return <ListToolBar />;
      case "column":
        return <ColumnToolBar />;
      case "file":
        return <FileToolBar />;
      case "board":
        return <BoardToolBar />;
      default:
        return !editMode ? (
          <MainToolSetsWithSharingMode
            editMode={editMode}
            addMode={addMode}
            setEditMode={setEditMode}
            setAddMode={setAddMode}
            removeElementFromBoard={removeElementFromBoard}
            handleStickerChose={handleStickerChose}
            selectedItemId={selectedItemId}
            selectedItemType={selectedItemType}
            setSelectedItemType={setSelectedItemType}
          />
        ) : (
          <MainToolSetsWithEditMode
            editMode={editMode}
            addMode={addMode}
            setEditMode={setEditMode}
            setAddMode={setAddMode}
            removeElementFromBoard={removeElementFromBoard}
            handleStickerChose={handleStickerChose}
            selectedItemId={selectedItemId}
            selectedItemType={selectedItemType}
            setSelectedItemType={setSelectedItemType}
          />
        );
    }
  } else {
    return (
      <MainToolSetsWithSharingMode
        editMode={editMode}
        addMode={addMode}
        setEditMode={setEditMode}
        setAddMode={setAddMode}
        removeElementFromBoard={removeElementFromBoard}
        handleStickerChose={handleStickerChose}
        selectedItemId={selectedItemId}
        selectedItemType={selectedItemType}
        setSelectedItemType={setSelectedItemType}
      />
    );
  }
};

const Toolbar: React.FC<ToolbarProps> = ({
  editMode,
  addMode,
  setEditMode,
  setAddMode,
  removeElementFromBoard,
  handleStickerChose,
  selectedItemId,
  selectedItemType,
  setSelectedItemType,
}) => {
  return (
    <>
      <View
        style={[
          styles.toolbar,
          {
            backgroundColor: editMode ? "#F7F7FA" : "transparent",
          },
        ]}
      >
        <ScrollView
          contentContainerStyle={styles.scrollBarTool}
          showsVerticalScrollIndicator={false}
          style={{ overflow: "visible" }}
          // className="overflow-y-hidden overflow-x-visible"
        >
          <CustomToolbar
            editMode={editMode}
            addMode={addMode}
            setEditMode={setEditMode}
            setAddMode={setAddMode}
            removeElementFromBoard={removeElementFromBoard}
            handleStickerChose={handleStickerChose}
            selectedItemId={selectedItemId}
            selectedItemType={selectedItemType}
            setSelectedItemType={setSelectedItemType}
          />
        </ScrollView>

        {editMode && (
          <>
            <View>
              <Button.Transparent
                onPress={() => {
                  removeElementFromBoard();
                  setSelectedItemType(null);
                }}
              >
                <Image source={require("../../assets/icons/bin.png")} />
              </Button.Transparent>
            </View>
            <View>
              <Button.Round
                onPress={() => {
                  setEditMode(!editMode);
                  setAddMode(null);
                  setSelectedItemType(null);
                }}
              >
                <Image source={require("../../assets/icons/minus.png")} />
              </Button.Round>
            </View>
          </>
        )}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  toolbar: {
    paddingVertical: 10,
    width: 50,
    height: height * 0.7,
    position: "absolute",
    right: 20,
    bottom: 20,
    overflow: "visible",
    borderRadius: 30,
    justifyContent: "flex-end",
  },
  scrollBarTool: {
    flexGrow: 1,
    gap: 15,
    justifyContent: "flex-end",
    overflow: "visible",
  },
  customToolbar: {
    position: "absolute",
    top: 10,
    left: 70,
    backgroundColor: "#F7F7FA",
    borderRadius: 10,
    padding: 10,
  },
});

export default Toolbar;
