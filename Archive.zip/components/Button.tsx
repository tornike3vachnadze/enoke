import { Pressable, Text, View } from "react-native";

function ButtonRound({
  onPress,
  title,
  className,
  children,
}: {
  onPress?: () => void;
  title?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <Pressable
      onPress={onPress}
      className={`flex flex-col justify-center items-center ${className}`}
    >
      <View className="bg-white w-10 h-10 flex justify-center items-center rounded-full">
        {children}
      </View>
      {title && (
        <Text
          style={{
            fontSize: 12,
          }}
          className="mt-1 text-design-secondary font-light font-satoshi-light"
        >
          {title}
        </Text>
      )}
    </Pressable>
  );
}

function ButtonSquare({
  onPress,
  title,
  className,
  active = false,
  children,
}: {
  onPress?: () => void;
  title?: string;
  className?: string;
  active?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Pressable
      onPress={onPress}
      className={`flex flex-col justify-center items-center ${className}`}
    >
      <View
        className={`bg-white w-10 h-10 flex justify-center items-center rounded-lg shadow ${
          active ? "border-2 border-design-primary" : ""
        }`}
      >
        {children}
      </View>
      {title && (
        <Text
          style={{
            fontSize: 12,
          }}
          className="mt-1 text-design-secondary font-light font-satoshi-light"
        >
          {title}
        </Text>
      )}
    </Pressable>
  );
}

function ButtonTransparent({
  onPress,
  title,
  className,
  active = false,
  children,
}: {
  onPress?: () => void;
  title?: string;
  className?: string;
  active?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Pressable
      onPress={onPress}
      className={`flex flex-col justify-center items-center ${className}`}
    >
      <View
        className={`bg-tr w-10 h-10 flex justify-center items-center rounded-lg shadow ${
          active ? "border-2 border-design-primary" : ""
        }`}
      >
        {children}
      </View>
      {title && (
        <Text
          style={{
            fontSize: 12,
          }}
          className="mt-1 text-design-secondary font-light font-satoshi-light"
        >
          {title}
        </Text>
      )}
    </Pressable>
  );
}

const Button = {
  Round: ButtonRound,
  Square: ButtonSquare,
  Transparent: ButtonTransparent,
};

export default Button;
