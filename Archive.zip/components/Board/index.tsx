import {
  View,
  Image,
  Keyboard,
  ImageBackground,
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Alert,
} from "react-native";
import {
  Gesture,
  GestureDetector,
  GestureHandlerRootView,
} from "react-native-gesture-handler";
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import Button from "../Button";
import { memo, useEffect, useMemo, useState } from "react";
import { BoardData, IBoardItem, ItemTypes } from "../../types";
import BoardItem from "./Item";
import TextContent from "./content/Text";
import ImageContent from "./content/Image";
import { useMedia } from "../../hooks";
import VideoContent from "./content/Video";
import AudioContent from "./content/Audio";
import UrlContent from "./content/URL";
import StickerGroup from "./group/StickerGroup";
import StickerContent from "./content/Sticker";
import DrawingContent from "./content/Drawing";
import LineContent from "./content/Line";
import ListContent from "./content/List";
import ColumnContent from "./content/column/Column";
import FileContent from "./content/file/File";
import { G, Svg } from "react-native-svg";
import BoardContent from "./content/Board";
import Toolbar from "../toolbar/Toolbar";
import ProfileCard from "../ProfileCard";
import { useGlobalStore } from "../../store";
import { getArrayBufferForBlob } from "react-native-blob-jsi-helper";
import { useBoardServer } from "../../hooks/server/useBoardServer";

const RANGE = 1500;
const { width, height } = Dimensions.get("window");

function BoardComponent({
  id,
  data,
  boardCoordinate,
}: {
  id: string;
  data: BoardData;
  boardCoordinate: { x: number; y: number } | null;
}) {
  const setIsLoading = useGlobalStore((state) => state.setIsLoading);

  const { pickImage, takePhoto, pickVideo, pickDocument, uploadFile } =
    useMedia();

  const { updateBoard } = useBoardServer();

  const [boardData, setBoardData] = useState(data);

  const [editMode, setEditMode] = useState(false);
  // TODO define new type based on new flow -- old :
  const [addMode, setAddMode] = useState<{
    type: ItemTypes;
    target: any;
  } | null>(null);

  const [selectedElementId, setSelectedElementId] = useState("");

  const [selectedItemType, setSelectedItemType] = useState<ItemTypes | null>(
    null
  );

  const [lastBoardLocation, setLastBoardLocation] = useState<{
    x: number;
    y: number;
  }>({
    x: 0,
    y: 0,
  });
  const [composeMode, setComposeMode] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await updateBoard(id, boardData);
      } catch (e) {
        console.log(e);
      }
    })();
  }, [boardData]);

  const isPressed = useSharedValue(false);
  const offset = useSharedValue({ x: 0, y: 0 });
  const velocity = useSharedValue({ x: 0, y: 0 });

  // const addTextToBoard = (e: any) => {
  //   console.log("text", e);
  //   const item: IBoardItem = {
  //     id: `${Date.now()}`,
  //     type: "text",
  //     content: {
  //       type: "text",
  //       data: "Hold me to Start typing...",
  //     },
  //     initialPos: [e.absoluteX, e.absoluteY],
  //     initialRot: 0,
  //     initialScale: 1,
  //   };
  //   setBoardData((prev) => [...prev, item]);
  // };

  const addTextToBoard = (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "text",
      content: {
        type: "text",
        data: "Hold me to Start typing...",
      },

      initialPos: [
        e.absoluteX - startOffset.value.x - 32,
        e.absoluteY - startOffset.value.y - 145,
      ], //28.3 : height of default text that i get it from inspector
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addLocalImageToBoard = async (e: any) => {
    setIsLoading(true);
    try {
      const image = await pickImage();
      if (image) {
        const blob = await fetch(image).then((r) => r.blob());
        const arrayBuffer = getArrayBufferForBlob(blob);
        const buffer = Buffer.from(arrayBuffer);
        const uploadRes = await uploadFile(
          buffer,
          `${image.split("/").pop()?.split(".")[0]}-${Date.now()}-${Math.floor(
            Math.random() * 99999
          )}.${blob.type.split("/")[1]}`,
          blob.type
        );
        if (uploadRes.success) {
          const item: IBoardItem = {
            id: `${Date.now()}`,
            type: "image",
            content: {
              type: "image",
              data: uploadRes.data?.url,
            },
            initialPos: [e.x, e.y],
            initialRot: 0,
            initialScale: 1,
          };
          setBoardData((prev) => [...prev, item]);
        } else {
          Alert.alert("Error", "Something went wrong");
        }
      }
    } catch (error) {
      console.log(error);
      Alert.alert("Error", "Something went wrong");
    }
    setIsLoading(false);
  };

  const addCameraImageToBoard = async (e: any) => {
    setIsLoading(true);
    try {
      const image = await takePhoto();
      if (image) {
        const blob = await fetch(image).then((r) => r.blob());
        const arrayBuffer = getArrayBufferForBlob(blob);
        const buffer = Buffer.from(arrayBuffer);
        const uploadRes = await uploadFile(
          buffer,
          `${image.split("/").pop()?.split(".")[0]}-${Date.now()}-${Math.floor(
            Math.random() * 99999
          )}.${blob.type.split("/")[1]}`,
          blob.type
        );
        if (uploadRes.success) {
          const item: IBoardItem = {
            id: `${Date.now()}`,
            type: "image",
            content: {
              type: "image",
              data: uploadRes.data?.url,
            },
            initialPos: [e.x, e.y],
            initialRot: 0,
            initialScale: 1,
          };
          setBoardData((prev) => [...prev, item]);
        } else {
          Alert.alert("Error", "Something went wrong");
        }
      }
    } catch (error) {
      console.log(error);
      Alert.alert("Error", "Something went wrong");
    }
    setIsLoading(false);
  };

  const addLocalVideoToBoard = async (e: any) => {
    setIsLoading(true);
    try {
      const video = await pickVideo();
      if (video) {
        const blob = await fetch(video).then((r) => r.blob());
        const arrayBuffer = getArrayBufferForBlob(blob);
        const buffer = Buffer.from(arrayBuffer);
        const uploadRes = await uploadFile(
          buffer,
          `${video.split("/").pop()?.split(".")[0]}-${Date.now()}-${Math.floor(
            Math.random() * 99999
          )}.${blob.type.split("/")[1]}`,
          blob.type
        );
        if (uploadRes.success) {
          const item: IBoardItem = {
            id: `${Date.now()}`,
            type: "video",
            content: {
              type: "video",
              data: video,
            },
            initialPos: [e.x, e.y],
            initialRot: 0,
            initialScale: 1,
          };
          setBoardData((prev) => [...prev, item]);
        } else {
          Alert.alert("Error", "Something went wrong");
        }
      }
    } catch (error) {
      console.log(error);
      Alert.alert("Error", "Something went wrong");
    }
    setIsLoading(false);
  };

  const addAudioToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "audio",
      content: {
        type: "audio",
        data: null,
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addUrlToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "url",
      content: {
        type: "url",
        data: null,
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addLineToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "line",
      content: {
        type: "line",
        data: {
          left: {
            x: 0,
            y: 100,
          },
          center: {
            x: 0,
            y: 0,
          },
          right: {
            x: 100,
            y: 15,
          },
        },
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addListToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "list",
      content: {
        type: "list",
        data: null,
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addDrawingToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,

      type: "drawing",
      content: {
        type: "drawing",
        data: "",
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addColumnToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "column",
      content: {
        type: "column",
        data: null,
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addStickerToBoard = async (e: any, data: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "sticker",
      content: {
        type: "sticker",
        data: data,
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const addFileToBoard = async (e: any) => {
    const file = await pickDocument();
    if (file) {
      const item: IBoardItem = {
        id: `${Date.now()}`,
        type: "file",
        content: {
          type: "file",
          data: file,
        },
        initialPos: [e.x, e.y],
        initialRot: 0,
        initialScale: 1,
      };
      setBoardData((prev) => [...prev, item]);
    }
  };

  const addBoardToBoard = async (e: any) => {
    const item: IBoardItem = {
      id: `${Date.now()}`,
      type: "board",
      content: {
        type: "board",
        data: null,
      },
      initialPos: [e.x, e.y],
      initialRot: 0,
      initialScale: 1,
    };
    setBoardData((prev) => [...prev, item]);
  };

  const removeElementFromBoard = () => {
    setBoardData((prevData) =>
      prevData.filter((item) => item.id !== selectedElementId)
    );
  };

  const handleStickerChose = (data: any) => {
    addStickerToBoard(lastBoardLocation, data);
  };

  const animatedStyles = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateX: withSpring(offset.value.x, {
            velocity: 0,
            damping: 100,
          }),
        },
        {
          translateY: withSpring(offset.value.y, {
            velocity: 0,
            damping: 100,
          }),
        },
      ],
    };
  });

  const [lockedForDraw, setLockedForDraw] = useState<boolean>(false);

  const startOffset = useSharedValue({ x: 0, y: 0 });

  const gesture = Gesture.Pan()
    .enabled(true)
    .enableTrackpadTwoFingerGesture(true)
    .onBegin(() => {
      isPressed.value = true;
    })
    .onUpdate((e) => {
      offset.value = {
        x: Math.min(
          Math.max(e.translationX + startOffset.value.x, -RANGE + width),
          0
        ),
        y: Math.min(
          Math.max(e.translationY + startOffset.value.y, -RANGE + height),
          0
        ),
      };
      velocity.value = {
        x: e.velocityX,
        y: e.velocityY,
      };
    })
    .onEnd(() => {
      console.log("sdfsadfsdfdf1");
      startOffset.value = {
        x: offset.value.x,
        y: offset.value.y,
      };
      runOnJS(setSelectedItemType)(null);
    })
    .onFinalize((e) => {
      console.log("sdfsadfsdfdf2");
      isPressed.value = false;
      console.log("last location", e);
      runOnJS(setLastBoardLocation)({
        x: e.translationX,
        y: e.translationY,
      });
    });

  useEffect(() => {
    if (addMode) {
      if (addMode.type === "text") {
        // runOnJS(addTextToBoard)(e);
        addTextToBoard(addMode.target);
      }
      // if (addMode === "image") {
      //   runOnJS(addLocalImageToBoard)(e);
      // }
      // if (addMode === "camera") {
      //   runOnJS(addCameraImageToBoard)(e);
      // }
      // if (addMode === "video") {
      //   runOnJS(addLocalVideoToBoard)(e);
      // }
      // if (addMode === "audio") {
      //   runOnJS(addAudioToBoard)(e);
      // }
      // if (addMode === "url") {
      //   runOnJS(addUrlToBoard)(e);
      // }
      // if (addMode === "drawing") {
      //   runOnJS(addDrawingToBoard)(e);
      //   runOnJS(setEditMode)(true);
      //   runOnJS(setLockedForDraw)(true);
      // }

      // if (addMode === "sticker") {
      //   runOnJS(handleStickerChose)(e);
      // }

      // if (addMode === "line") {
      //   runOnJS(addLineToBoard)(e);
      // }
      // if (addMode === "list") {
      //   runOnJS(addListToBoard)(e);
      // }
      // if (addMode === "column") {
      //   runOnJS(addColumnToBoard)(e);
      // }
      // if (addMode === "file") {
      //   runOnJS(addFileToBoard)(e);
      // }
      // if (addMode === "board") {
      //   runOnJS(addBoardToBoard)(e);
      // }

      // runOnJS(setAddMode)(null);
      setAddMode(null);
    }
  }, [addMode]);

  return (
    <>
      <Pressable onPressIn={Keyboard.dismiss}>
        <GestureDetector gesture={gesture}>
          <Animated.View
            style={[animatedStyles, { width: RANGE, height: RANGE }]}
            className="px-4 py-6 "
          >
            <ImageBackground
              source={require("../../assets/images/dotgrid.png")}
              style={{ width: "200%", height: "200%" }}
              resizeMode="cover"
              resizeMethod="resize"
            >
              <View>
                <Svg
                  width={500}
                  height={500}
                  viewBox="0 0 1000 1000"
                  style={{
                    backgroundColor: "transparent",
                    position: "absolute",
                    transform: [
                      { scale: 3 },
                      { translateX: 150 },
                      { translateY: 150 },
                    ],
                  }}
                >
                  <G transform={`scale(${1})`}>
                    {useMemo(() => {
                      return boardData.map((item, index) => (
                        <G key={item.id}>
                          {item.type === "line" && (
                            <LineContent
                              index={index}
                              boardData={boardData}
                              setBoardData={setBoardData}
                              pos={{
                                x: item.initialPos[0],
                                y: item.initialPos[1],
                              }}
                              onClick={() => setSelectedElementId(item.id)}
                              pathValues={{
                                left: {
                                  x: item.content.data.left.x || 0,
                                  y: item.content.data.left.y || 100,
                                },
                                center: {
                                  x: item.content.data.center.x || 0,
                                  y: item.content.data.center.y || 0,
                                },
                                right: {
                                  x: item.content.data.right.x || 100,
                                  y: item.content.data.right.y || 15,
                                },
                              }}
                            ></LineContent>
                          )}
                        </G>
                      ));
                    }, [boardData])}
                  </G>
                </Svg>
                {boardData.map((item, index) => (
                  <BoardItem
                    index={index}
                    initalPos={item.initialPos}
                    initialRotate={item.initialRot}
                    initialScale={item.initialScale}
                    onClick={() => {
                      setSelectedElementId(item.id);
                      setSelectedItemType(item.type);
                    }}
                    isEditing={editMode}
                    key={item.id}
                    boardData={boardData}
                    setBoardData={setBoardData}
                  >
                    {item.type === "text" && (
                      <TextContent index={index} setBoardData={setBoardData}>
                        {item.content.data}
                      </TextContent>
                    )}
                    {item.type === "image" && (
                      <ImageContent
                        index={index}
                        setBoardData={setBoardData}
                        url={item.content as any}
                      ></ImageContent>
                    )}
                    {item.type === "video" && (
                      <VideoContent
                        index={index}
                        setBoardData={setBoardData}
                        url={item.content as any}
                      ></VideoContent>
                    )}
                    {item.type === "audio" && (
                      <AudioContent
                        index={index}
                        setBoardData={setBoardData}
                        url={item.content as any}
                      ></AudioContent>
                    )}
                    {item.type === "url" && (
                      <UrlContent
                        index={index}
                        setBoardData={setBoardData}
                        url={item.content as any}
                      ></UrlContent>
                    )}
                    {item.type === "sticker" && (
                      <StickerContent
                        index={index}
                        setBoardData={setBoardData}
                        uri={item.content.data}
                      ></StickerContent>
                    )}

                    {item.type === "drawing" && (
                      <DrawingContent
                        index={index}
                        initialPath={item.content.data}
                        setBoardData={setBoardData}
                      ></DrawingContent>
                    )}

                    {item.type === "list" && (
                      <ListContent
                        index={index}
                        setBoardData={setBoardData}
                      ></ListContent>
                    )}
                    {item.type === "column" && (
                      <ColumnContent
                        index={index}
                        setBoardData={setBoardData}
                      ></ColumnContent>
                    )}
                    {item.type === "file" && (
                      <FileContent
                        index={index}
                        setBoardData={setBoardData}
                        data={item.content.data}
                      ></FileContent>
                    )}
                    {item.type === "board" && (
                      <BoardContent
                        index={index}
                        setBoardData={setBoardData}
                        data={item.content.data}
                      ></BoardContent>
                    )}
                    {item.type === "profile" && (
                      <ProfileCard
                        style={{
                          width: 350,
                        }}
                        username={item.content.data}
                      />
                    )}
                  </BoardItem>
                ))}
              </View>
            </ImageBackground>
          </Animated.View>
        </GestureDetector>
      </Pressable>

      <Toolbar
        editMode={editMode}
        addMode={addMode}
        setEditMode={setEditMode}
        setAddMode={setAddMode}
        removeElementFromBoard={removeElementFromBoard}
        handleStickerChose={handleStickerChose}
        selectedItemId={selectedElementId}
        selectedItemType={selectedItemType}
        setSelectedItemType={setSelectedItemType}
      />
    </>
  );
}

const styles = StyleSheet.create({
  toolbar: {
    backgroundColor: "#F7F7FA",
    paddingVertical: 10,
    width: 50,
    height: height * 0.7,
    position: "absolute",
    right: 20,
    bottom: 20,
    overflow: "visible",
    borderRadius: 30,
  },
  scrollBarTool: {
    gap: 15,
    justifyContent: "flex-end",
  },
});

const Board = memo(BoardComponent);

export default Board;
