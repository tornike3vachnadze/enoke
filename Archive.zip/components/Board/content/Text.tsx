import { useEffect, useState } from "react";
import {
  Pressable,
  Text,
  TextInput,
  TouchableWithoutFeedback,
  View,
} from "react-native";
import { BoardData } from "../../../types";

export default function TextContent({
  index,
  setBoardData,
  children,
}: {
  index: number;
  setBoardData: React.Dispatch<React.SetStateAction<BoardData>>;
  children: string;
}) {
  const [editable, setEditable] = useState(false);
  const [text, setText] = useState(children);

  useEffect(() => {
    setBoardData((prev) => {
      const newBoardData = [...prev];
      newBoardData[index].content.data = text;
      return newBoardData;
    });
  }, [text]);

  return (
    <Pressable className={``} onLongPress={() => setEditable(true)}>
      {!editable ? (
        <Text
          className={`font-bold font-satoshi-bold text-lg text-design-primary`}
        >
          {text}
        </Text>
      ) : (
        <TextInput
          value={text}
          onChangeText={setText}
          autoFocus
          multiline
          onBlur={() => setEditable(false)}
          className={`font-bold font-satoshi-bold text-lg text-design-primary p-0 ${
            editable ? "border-2 border-design-primary" : ""
          }`}
        />
      )}
    </Pressable>
  );
}
