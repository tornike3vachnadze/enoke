import { useRef, useState } from "react";
import { View, Dimensions, StyleSheet } from "react-native";
import { BoardData } from "../../../types";
import Svg, { Path } from "react-native-svg";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { runOnJS } from "react-native-reanimated";

const screenWidth = Dimensions.get("window").width;
const screenHeight = Dimensions.get("window").height;

export default function DrawingContent({
  index,
  initialPath,
  setBoardData,
}: {
  index: number;
  initialPath?: string;
  setBoardData: React.Dispatch<React.SetStateAction<BoardData>>;
}) {
  const [path, setPath] = useState<string>(initialPath || "");

  const [canDraw, setCanDraw] = useState<boolean>(true);

  const pathRef = useRef<Path>(null);

  const updateData = () => {
    setBoardData((prev) => {
      const newBoardData = [...prev];
      newBoardData[index].content.data = path;
      return newBoardData;
    });
  };

  const gesture = Gesture.Pan()
    .enabled(canDraw)
    .onBegin((e) => {
      const { x, y } = e;
      const initialPath = `M${x},${y}`;
      runOnJS(setPath)(initialPath);
    })
    .onUpdate((e) => {
      const { translationX, translationY } = e;
      const moveX = translationX + screenWidth / 2;
      const moveY = translationY + screenHeight / 2;

      const newPath = `${path} Q${moveX},${moveY} ${moveX},${moveY}`;
      runOnJS(setPath)(newPath);
    })
    .onEnd((e) => {})
    .onFinalize((e) => {
      runOnJS(setCanDraw)(false);
      runOnJS(updateData)();
    });

  return (
    <View pointerEvents="box-none">
      <GestureDetector gesture={gesture}>
        <View>
          <View
            style={
              canDraw
                ? styles.canDrawContainer
                : [
                    styles.pathContainer,
                    {
                      width: pathRef?.current?.getBBox().width,
                      height: pathRef?.current?.getBBox().height,
                    },
                  ]
            }
            pointerEvents="box-none"
          >
            <Svg width="100%" height="100%" style={styles.svg}>
              <Path
                d={path}
                stroke="#6C68A8"
                strokeWidth="2"
                fill="none"
                ref={pathRef}
              />
            </Svg>
          </View>
        </View>
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  canDrawContainer: {
    alignSelf: "center",
    width: screenWidth,
    height: screenHeight,
    backgroundColor: "transparent",
  },
  pathContainer: {
    position: "absolute",
    left: -screenWidth / 2,
    top: -screenHeight / 2,
    bottom: 0,
    right: 0,
    backgroundColor: "transparent",
  },
  svg: {
    backgroundColor: "transparent",
  },
});
