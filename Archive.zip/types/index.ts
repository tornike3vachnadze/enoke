export type ItemTypes =
  | "text"
  | "image"
  | "audio"
  | "camera"
  | "video"
  | "url"
  | "line"
  | "sticker"
  | "drawing"
  | "list"
  | "column"
  | "file"
  | "board"
  | "delete"
  | "profile";
export type ItemContentType =
  | "text"
  | "image"
  | "localimage"
  | "audio"
  | "video"
  | "url"
  | "line"
  | "sticker"
  | "drawing"
  | "list"
  | "column"
  | "board"
  | "file"
  | "profile";

export type FileTypes = "pdf" | "obj";

export interface IBoardItem {
  id: string;
  type: ItemTypes;
  content: {
    type: ItemContentType;
    data: string | number | any;
  };
  initialPos: [number, number];
  initialRot: number;
  initialScale: number;
}

export type BoardData = IBoardItem[];

export interface Friend {
  name: string;
  imageURL: string;
}

export type ChatPreview = {
  uid: string;
  friend: Friend;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
};

export type SelectionType =
  | "interests"
  | "looking_for"
  | "location"
  | "languages"
  | "zodiac"
  | "enneagram";
