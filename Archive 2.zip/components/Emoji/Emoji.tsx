import { Dimensions, StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import EmojiModal from "react-native-emoji-modal";
import Animated, { useAnimatedStyle } from "react-native-reanimated";
const { width, height } = Dimensions.get("screen");

const BOX_SIZE = {
  width: width * 0.7,
  height: width,
};
const OFFSET = {
  width: 0,
  height: 0,
};

const EmojiSelector = ({
  position,
  onPressOutside,
}: {
  position: { x: number; y: number };
  onPressOutside: () => void;
}) => {
  const [recent, setRecent] = useState([]);
  const animatedStyle = useAnimatedStyle(() => {
    return {
      // transform: [
      //   { translateX: position.x - BOX_SIZE.width },
      //   { translateY: position.y },
      // ],
      left: position.x - BOX_SIZE.width - OFFSET.width,
      top: position.y - BOX_SIZE.height - OFFSET.height,
    };
  });
  return (
    <Animated.View
      style={[
        {
          position: "absolute",
          width: BOX_SIZE.width,
          height: BOX_SIZE.height,
          shadowColor: "#000",
          shadowOpacity: 0.1,
          shadowRadius: 5,
          shadowOffset: {
            width: 0,
            height: 0,
          },
        },
        animatedStyle,
      ]}
    >
      <EmojiModal
        onEmojiSelected={(emoji) => {}}
        searchStyle={{ display: "none" }}
        backgroundStyle={{ backgroundColor: "transparent" }}
        modalStyle={{ backgroundColor: "transparent" }}
        shortcutColor={"red"}
        onPressOutside={onPressOutside}
        columns={6}
      />
    </Animated.View>
  );
};

export default EmojiSelector;

const styles = StyleSheet.create({});
