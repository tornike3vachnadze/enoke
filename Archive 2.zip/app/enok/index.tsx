import { Text, View } from "react-native";

export default function Experience() {
  return (
    <View className="flex">
      <Text>Main Experience</Text>
    </View>
  );
}
